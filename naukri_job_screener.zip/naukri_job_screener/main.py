#!/usr/bin/env python
"""Naukri job screener - find the jobs that actually match you.

    python main.py --setup              create config.yaml and show what's next
    python main.py --resume my_cv.pdf   parse your resume into facts
    python main.py --login              sign in to Naukri once, save the session
    python main.py --extract            read your live Naukri profile (optional)
    python main.py --scan               search, score, rank, write the results
    python main.py --check              show the config without touching a browser
    python main.py --roles              list role packs, and which fits your resume
    python main.py --new-role NAME      scaffold a pack for a field with none

Start with --setup. It tells you which of the rest you need.
"""
from __future__ import annotations

import argparse
import logging
import shutil
import sys
from pathlib import Path

from screener import config as config_mod
from screener import paths, resume as resume_mod, scan as scan_mod

EXAMPLE_CONFIG = paths.ROOT / "config.example.yaml"

# Windows consoles default to cp1252, and salary fields carry a rupee sign -
# printing a summary would raise UnicodeEncodeError and lose an otherwise
# successful run. Degrade unprintable characters instead.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


def _setup_logging(verbose: bool) -> None:
    paths.LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(paths.LOG_DIR / "screener.log", encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


def cmd_setup() -> int:
    paths.ensure()
    target = paths.CONFIG_PATH
    if target.exists():
        print(f"\n  {target} already exists - leaving it alone.\n")
    else:
        shutil.copy(EXAMPLE_CONFIG, target)
        print(f"\n  Created {target}")

    roles = config_mod.available_roles()
    print(f"""
  Next, in order:

    1. Put your resume in
         {paths.RESUME_DIR}
       then run:  python main.py --resume

    2. Pick a role pack. Available:
         {', '.join(roles) if roles else '(none)'}
       Set `role:` in config.yaml. Skip it and the screener works off your
       resume alone, just less precisely.

    3. Sign in once:
         python main.py --login

    4. Check what it will do, without opening a browser:
         python main.py --check

    5. Run it:
         python main.py --scan
""")
    return 0


def cmd_roles() -> int:
    roles = config_mod.available_roles()
    if not roles:
        print(f"\n  No role packs found in {paths.PROFILES_DIR}\n")
        return 1

    # If a resume has been parsed, say which pack it matches - that is the
    # question someone running --roles is actually asking.
    facts = resume_mod.load()
    detected, scores = config_mod.detect_role(facts) if facts else (None, {})

    print(f"\n  Role packs in {paths.PROFILES_DIR}:\n")
    for role in roles:
        try:
            pack = config_mod.load_pack(role)
        except config_mod.ConfigError:
            continue
        description = pack.get("description") or ""
        mark = " <- matches your resume" if role == detected else ""
        print(f"    {role:<24} {description}{mark}")

    if facts and not detected:
        ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:2]
        print("\n  None of these clearly matches your resume"
              + (f" (closest: {', '.join(r for r, _ in ranked)})." if ranked else ".")
              + "\n  Either pick one anyway, or make your own:"
              + "\n      python main.py --new-role \"Android Developer\"")
    elif not facts:
        print("\n  Run `python main.py --resume <cv>` and this will tell you which one fits.")

    print("\n  Set one as `role:` in config.yaml.\n")
    return 0


def cmd_new_role(name: str) -> int:
    facts = resume_mod.load()
    path = config_mod.scaffold_pack(name, facts)
    seeded = "seeded from your resume" if facts else "empty - fill in the lists"
    print(f"""
  Created {path}  ({seeded})

  Open it and check three lists:

    searches        job TITLES as postings word them, not skills.
                    "Java Developer", not "Hibernate".
    must_have_any   the "is this my field" gate. Too narrow and you see
                    nothing; too broad and the neighbouring field leaks in.
    vocabulary      every tool and term in your field. This is also what
                    role detection matches against, so length helps.

  Then set it in config.yaml:

      role: {path.stem}

  Check it before running a scan:

      python main.py --check

  If it works, a pull request adding it helps the next person in your field.
""")
    return 0


def cmd_resume(path_arg: str | None) -> int:
    paths.ensure()
    vocabulary: list[str] = []
    try:
        # The role pack's vocabulary makes the parse sharper, but a config that
        # cannot load yet (no facts on disk - which is exactly the case on a
        # first run) must not block parsing the resume that would fix that.
        raw = config_mod.load_pack(_role_from_config())
        vocabulary = list(raw.get("vocabulary") or [])
    except config_mod.ConfigError as exc:
        logging.getLogger("screener").debug("No role pack for the parse: %s", exc)

    source = Path(path_arg) if path_arg else None
    facts = resume_mod.parse(source, vocabulary=vocabulary)

    # A resume dropped in from elsewhere is copied in, so later runs find it
    # without the user having to remember the path they typed once.
    if source and source.exists() and source.parent.resolve() != paths.RESUME_DIR.resolve():
        paths.RESUME_DIR.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy(source, paths.RESUME_DIR / source.name)
        except OSError as exc:
            logging.getLogger("screener").debug("Could not copy the resume in: %s", exc)

    resume_mod.save(facts)
    print("\n" + resume_mod.summarise(facts) + "\n")
    return 0


def _role_from_config() -> str | None:
    """Read just `role:` out of config.yaml, tolerating an otherwise broken file."""
    if not paths.CONFIG_PATH.exists():
        return None
    try:
        import yaml
        loaded = yaml.safe_load(paths.CONFIG_PATH.read_text(encoding="utf-8")) or {}
        return loaded.get("role") if isinstance(loaded, dict) else None
    except Exception:
        return None


def cmd_check() -> int:
    config = config_mod.load()
    print("\n" + config_mod.summarise(config) + "\n")
    missing = []
    if not paths.NAUKRI_STATE.exists():
        missing.append("  No saved Naukri session. Run: python main.py --login")
    if config.get("profile_years") is None:
        missing.append("  Experience unknown - experience scoring will sit mid-band.\n"
                       "    Set `years:` in config.yaml.")
    if missing:
        print("\n".join(missing) + "\n")
    return 0


def cmd_scan(args) -> int:
    config = config_mod.load()
    if args.source:
        config["source"] = args.source
    if args.posted_days is not None:
        config["posted_within_days"] = args.posted_days
    config["headless"] = args.headless

    print("\n" + config_mod.summarise(config) + "\n")

    summary = scan_mod.run(config, refresh=args.refresh, limit=args.limit)
    written = scan_mod.write(summary, config, excel=not args.no_excel, html=not args.no_html)
    print(scan_mod.summarise(summary, written))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--setup", action="store_true", help="Create config.yaml and print the next steps")
    action.add_argument("--roles", action="store_true", help="List the role packs and say which fits your resume")
    action.add_argument("--new-role", dest="new_role", metavar="NAME",
                        help="Scaffold profiles/<name>.yaml for a field with no pack")
    action.add_argument("--resume", nargs="?", const=True, metavar="PATH",
                        help="Parse a resume into data/resume.json")
    action.add_argument("--login", action="store_true", help="Sign in to Naukri and save the session")
    action.add_argument("--extract", action="store_true", help="Read your live Naukri profile into data/")
    action.add_argument("--check", action="store_true", help="Print the effective config and exit")
    action.add_argument("--scan", action="store_true", help="Search, score and rank today's jobs")

    parser.add_argument("--source", choices=("local", "apify"), help="Override `source:` for this run")
    parser.add_argument("--limit", type=int, metavar="N", help="Keep at most N scored jobs")
    parser.add_argument("--posted-days", type=float, default=None, dest="posted_days", metavar="N",
                        help="Only listings posted in the last N days")
    parser.add_argument("--refresh", action="store_true",
                        help="Re-score jobs already in the ledger (use after editing config.yaml)")
    parser.add_argument("--headless", action="store_true",
                        help="Run the browser headless. Naukri's bot protection usually blocks this.")
    parser.add_argument("--no-excel", action="store_true", dest="no_excel", help="Skip the .xlsx")
    parser.add_argument("--no-html", action="store_true", dest="no_html", help="Skip the HTML page")
    parser.add_argument("-v", "--verbose", action="store_true", help="Debug logging")
    args = parser.parse_args()

    _setup_logging(args.verbose)

    try:
        if args.setup:
            return cmd_setup()
        if args.roles:
            return cmd_roles()
        if args.new_role:
            return cmd_new_role(args.new_role)
        if args.resume:
            return cmd_resume(None if args.resume is True else args.resume)
        if args.check:
            return cmd_check()
        if args.scan:
            return cmd_scan(args)

        if args.login:
            from screener import session as session_mod
            paths.ensure()
            return 0 if session_mod.login() else 1

        if args.extract:
            from screener import extract as extract_mod
            paths.ensure()
            # Headless gets served "Access Denied" by Akamai, so this is headed.
            profile = extract_mod.extract(headless=False)
            print(extract_mod.summarise(profile))
            return 0

    except resume_mod.ResumeError as exc:
        print(f"\n  {exc}\n")
        return 2
    except config_mod.ConfigError as exc:
        print(f"\n  {exc}\n")
        return 2
    except KeyboardInterrupt:
        print("\n  Stopped.\n")
        return 130
    except Exception as exc:
        from screener.session import NotLoggedIn
        from screener.sources import SourceError
        if isinstance(exc, (NotLoggedIn, SourceError)):
            print(f"\n  {exc}\n")
            return 2
        logging.getLogger("screener").exception("Unhandled error")
        print(f"\n  Error: {exc}\n  See logs/screener.log\n")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
